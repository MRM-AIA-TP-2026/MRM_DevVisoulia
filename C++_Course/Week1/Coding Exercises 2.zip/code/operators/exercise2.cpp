#include <iostream>
using namespace std;

int main() {
  
  //add code below this line

cout << boolalpha << (5!=5)&&(4>5) ;

  //add code above this line
  
  return 0;
  
}
