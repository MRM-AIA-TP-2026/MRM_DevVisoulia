#include <iostream>
using namespace std;

int main() {
  
  //fix the code below this line

  int a = 5;
  string b = 9;

  //fix the code above this line
  
  cout << (a * 3 + b - 8 / 2) << endl;
  
  return 0;
  
}
