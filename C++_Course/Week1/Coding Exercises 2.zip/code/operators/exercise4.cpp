#include <iostream>
using namespace std;

int main() {
  
  //add code below this line
int a=7;
int b=2;
cout<<(double) a/b;


  //add code above this line
  
  return 0;
  
}
