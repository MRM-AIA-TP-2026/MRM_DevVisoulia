#include <iostream>
using namespace std;

int main() {
  
  //add code below this line
string a ="Hello ";
string b ="world";
cout<<a+b;


  //add code above this line
  
  return 0;
  
}
