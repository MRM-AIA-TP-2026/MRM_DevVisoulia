#include <iostream>
using namespace std;

int main() {
  
  //add code below this line
int my_int = 123;
cout << my_int << endl;
my_int = 321;
cout << my_int << endl;


  //add code above this line
  
  return 0;
  
}
