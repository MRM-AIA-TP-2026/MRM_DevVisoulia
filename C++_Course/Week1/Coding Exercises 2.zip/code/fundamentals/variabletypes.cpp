#include <iostream>
using namespace std;

int main() {

  //declaring (giving the variable a type)
  int number;
  bool true_or_false;
  char letter;

  //assigning (giving the variable a value)
  number = 99;
  true_or_false = true;
  letter = 'a';

  //accessing (retrieving the value of the data by printing)
  cout <<number <<endl;
  cout << true_or_false << endl;
  cout << letter << endl;

  return 0;
  
}
