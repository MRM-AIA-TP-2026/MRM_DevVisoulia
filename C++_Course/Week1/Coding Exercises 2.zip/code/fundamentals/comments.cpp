#include <iostream>
using namespace std;

int main() {

/*
This is a multi-line comment.
Multi-line comments start with a forward slash(/) followed by a star(*).
They end with a star(*) followed by a forward slash(/).
Try making one at the end of the code file.
*/

  //add code below this line
  
  cout << "Red" << endl; //this is a single-line comment
  cout << "Orange"; //the comment STARTS right after the double forward slash "//" symbol
  cout << endl;
  //cout << "Yellow" << endl;
  cout << "Green" << endl; //single-line comments end when a newline is detected
  cout << "Blue" << endl;
  cout << "Indigo" << endl;
  cout << "Violet" << endl;
  cout << "These are the colors of the rainbow!" << endl;
  
  //add code above this line
  
  return 0;
  
}
