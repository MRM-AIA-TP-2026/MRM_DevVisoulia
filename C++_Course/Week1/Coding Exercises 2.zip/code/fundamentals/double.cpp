#include <iostream>
using namespace std;

int main() {
  
  //add code below this line
double decimal = .001;
cout << decimal << endl;


  //add code above this line
  
  return 0;
  
}
