#include <iostream>
using namespace std;

int main() {
  
  //add code below this line
int dev;
string dev; 

  //add code above this line
  
  return 0;
  
}
