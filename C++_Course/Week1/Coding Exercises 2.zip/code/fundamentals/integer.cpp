#include <iostream>
using namespace std;

int main() {
  
  //add code below this line
int number = "50";
cout << number << endl;


  //add code above this line
  
  return 0;
  
}
