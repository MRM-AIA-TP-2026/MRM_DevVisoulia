#include <iostream>
using namespace std;

int main() {
  
  //add code below this line

String words = 'This is a string.';
cout << words << endl;

  //add code above this line
  
  return 0;
  
}
