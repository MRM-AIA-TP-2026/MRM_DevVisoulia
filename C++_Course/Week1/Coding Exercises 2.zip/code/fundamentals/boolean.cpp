#include <iostream>
using namespace std;

int main() {
  
  //add code below this line
bool thisIsFun = TRUE;
cout << boolalpha << thisIsFun << endl;


  //add code above this line
  
  return 0;
  
}
