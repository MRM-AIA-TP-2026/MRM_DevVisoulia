#!/bin/bash

cd code/loops
$1 $2 $3 $4 && $5 $6
