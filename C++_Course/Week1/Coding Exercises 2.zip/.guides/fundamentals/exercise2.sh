cd code/fundamentals
g++ exercise2.cpp -o exercise2
./exercise2 $1 $2 $3
