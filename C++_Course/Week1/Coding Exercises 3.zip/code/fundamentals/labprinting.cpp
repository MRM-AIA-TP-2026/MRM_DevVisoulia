#include <iostream>
using namespace std;

int main() {
  
  //add code below this line
  
string my_var = "I am learning"; //step 1
cout << my_var; //step 2
my_var = " to program"; //step 3
cout << my_var; //step 4
my_var = " in C++."; //step 5
cout << my_var << endl; //step 6
my_var = "Hooray!"; //step 7
cout << my_var; //step 8
  
  //add code above this line
  
  return 0;
  
}
