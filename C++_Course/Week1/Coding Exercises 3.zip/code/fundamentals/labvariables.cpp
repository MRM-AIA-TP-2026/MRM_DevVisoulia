#include <iostream>
using namespace std;

int main() {
  
  //add code below this line
int one = 1;
int two = 2;
int three = 3;
int four = 4;

two = one;
three = two;
four = three;

cout << four;


  //add code above this line
  
  return 0;
  
}
