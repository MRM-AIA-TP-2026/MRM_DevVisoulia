#include <iostream>
using namespace std;

int main(int argc, char** argv) {
  
  string greeting = argv[1];
  string dayOfWeek = argv[2];
  string month = argv[3];
  int day = atoi(argv[4]);
  int currentWaitMinutes = atoi(argv[5]);
  
  //add code below this line
string to_print_1="*greeting* Today is *dayOfWeek, *month* *day*";
string to_print_2="The current wait time is *currentWaitMinutes* minutes.";
cout<< to_print_1 <<endl;
cout<< to_print_2 <<endl;




  //add code above this line
  
  return 0;
  
}
