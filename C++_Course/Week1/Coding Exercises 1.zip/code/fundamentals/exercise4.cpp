#include <iostream>
using namespace std;

int main(int argc, char** argv) {
  
  double number = atof(argv[1]);
  
  //add code below this line



  //add code above this line
  
  return 0;
  
}
