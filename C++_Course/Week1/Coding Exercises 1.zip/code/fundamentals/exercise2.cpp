#include <iostream>
using namespace std;

int main(int argc, char** argv) {
  
  int first_num = atoi((argv[1]));
  int second_num = atoi((argv[2]));
  int third_num = atoi((argv[3]));
  
  //add code below this line
int my_int;
my_int=first_num;
cout<<my_int<<endl;
my_int=second_num;
cout<<my_int<<endl;
my_int=third_num;
cout<<my_int<<endl;
  //add code above this line
  
  return 0;
  
}
