#include <iostream>
using namespace std;

int main() {

/*
This is the start of a multi-line comment.
You can end the comment with a star(*) followed by a forward slash(/).
*/

//You can also do a multi-line comment
//like this!
    
cout << "Notice how the comments above are lightly faded.";
cout << "Most IDEs automatically lighten the comments.";
cout << "This is a common feature known as syntax highlighting.";
  
  //add code above this line
  
  return 0;
  
}
