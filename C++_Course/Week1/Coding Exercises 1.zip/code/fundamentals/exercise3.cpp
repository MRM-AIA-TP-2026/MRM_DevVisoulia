#include <iostream>
using namespace std;

int main(int argc, char** argv) {
  
  string line1 = (argv[1]);
  string line2 = (argv[2]);
  
  //add code below this line
cout<<line1<<endl;
cout<<line2<<endl;

  //add code above this line
  
  return 0;
  
}
