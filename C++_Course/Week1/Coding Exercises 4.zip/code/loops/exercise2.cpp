#include <iostream>
using namespace std;

int main(int argc, char** argv) {
  
  string x = argv[1];
  
  //add code below this line
for(int i=1; i<=10 ;i++){
  cout<<x<<endl;
}


  //add code above this line
  
  return 0;
  
}
