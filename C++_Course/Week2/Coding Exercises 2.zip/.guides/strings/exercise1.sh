cd code/strings
g++ exercise1.cpp -o exercise1
./exercise1 $1
