cd code/pointers
g++ exercise1.cpp -o exercise1
./exercise1 $1 $2
