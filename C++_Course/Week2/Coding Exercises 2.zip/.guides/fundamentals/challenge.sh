cd code/fundamentals
g++ labchallenge.cpp -o labchallenge
./labchallenge $1 $2 $3 $4 $5
