#include <iostream>
#include <vector>
using namespace std;

int main() {
  
  //add code below this line



  //add code above this line
  
  return 0;
  
}
