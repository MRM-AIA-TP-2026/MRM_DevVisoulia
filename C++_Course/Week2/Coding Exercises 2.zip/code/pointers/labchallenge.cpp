#include <iostream>
using namespace std;

int main() {

  int age1 = 12;
  int age2 = 31;
  int age3 = 29;
  int* amy;
  int* bob;
  int** carol;
  
  //add code below this line
  
  
  cout << *amy << endl; //do not edit
  
  cout << *bob << endl; //do not edit
  
  cout << **carol << endl; //do not edit
  
  
  //add code above this line 
  
  return 0;
  
}