cd code/vectors
g++ exercise3.cpp -o exercise3
./exercise3 $1 $2 $3
