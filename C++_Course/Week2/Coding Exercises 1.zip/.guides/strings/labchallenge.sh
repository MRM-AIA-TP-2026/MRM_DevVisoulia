cd code/strings
g++ labchallenge.cpp -o labchallenge
./labchallenge $1
