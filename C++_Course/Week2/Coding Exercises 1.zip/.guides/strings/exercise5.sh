cd code/strings
g++ exercise5.cpp -o exercise5
./exercise5 $1
